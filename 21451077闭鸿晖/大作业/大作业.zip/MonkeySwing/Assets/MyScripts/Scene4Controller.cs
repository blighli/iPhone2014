﻿using UnityEngine;
using System.Collections;

public class Scene4Controller : MonoBehaviour {
	public GameObject bubble;
	public GameObject monkey;
	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		if(!monkey){
			return;
		}
		float monkeyY=monkey.transform.position.y;
		if(!bubble){
			return;
		}
		if(monkeyY>1&&monkeyY<3.5){
			Vector2 force = new Vector2(-1,0);
			bubble.rigidbody2D.AddForce(force*200*Time.deltaTime);
		}else{
			Vector2 force = new Vector2(1,0);
			bubble.rigidbody2D.AddForce(force*200*Time.deltaTime);
		}
	}
}
