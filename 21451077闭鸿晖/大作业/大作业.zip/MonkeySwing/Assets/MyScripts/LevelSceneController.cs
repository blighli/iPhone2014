﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.Events;

public class LevelSceneController : MonoBehaviour {

	public Sprite lockSprite;
	public Sprite unlockSprite;
	private GameObject levelPanel;
	// Use this for initialization

	//create level buttons
	void Start () {
		levelPanel=GameObject.Find("Canvas").transform.FindChild("Panel").gameObject;
		int myLevel=PlayerPrefs.GetInt("level",0);
		if(myLevel==0){
			myLevel++;
		}
		for(int i=1;i<=myLevel;i++){
			GameObject button = levelPanel.transform.FindChild("level"+i).gameObject;
			button.GetComponent<Image>().sprite=unlockSprite;
			button.transform.FindChild("Text").gameObject.GetComponent<Text>().text=i.ToString();
		}

		for(int i=myLevel+1;i<=9;i++){
			GameObject button = levelPanel.transform.FindChild("level"+i).gameObject;
			button.GetComponent<Image>().sprite=lockSprite;
			button.transform.FindChild("Text").gameObject.GetComponent<Text>().text="";
			button.GetComponent<Button>().onClick=null;
		}

	}

	public void loadLevel(int level){
		Application.LoadLevel(level);

	}

	// Update is called once per frame
	void Update () {
	
	}
}
