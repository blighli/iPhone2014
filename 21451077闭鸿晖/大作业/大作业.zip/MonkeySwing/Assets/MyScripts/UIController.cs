﻿using UnityEngine;
using System.Collections;

public class UIController : MonoBehaviour {

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
	
	}
	public void back(){
		int currentLevel = Application.loadedLevel;
		if(currentLevel>1){
			Application.LoadLevel(--currentLevel);
		}

	}

	public void restart(){
		int currentLevel = Application.loadedLevel;
		Application.LoadLevel(currentLevel);
	}

	public void menu(){
		transform.FindChild("menuPanel").gameObject.SetActive(true);
		Camera.main.transform.FindChild("knife").gameObject.SetActive(false);
	}

	public void resume(){
		Camera.main.transform.FindChild("knife").gameObject.SetActive(true);
		transform.FindChild("menuPanel").gameObject.SetActive(false);
	}

	public void chooseLevel(){
		Application.LoadLevel(5);

	}

	public void next(){
		int currentLevel = Application.loadedLevel;
		Application.LoadLevel(currentLevel);
		if(currentLevel<4){
			Application.LoadLevel(++currentLevel);
		}
		
	}

	public void quit(){
		Application.Quit();
	}

}
