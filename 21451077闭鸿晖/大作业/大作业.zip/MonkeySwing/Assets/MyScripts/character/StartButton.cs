﻿using UnityEngine;
using System.Collections;

public class StartButton : MonoBehaviour {

	// Use this for initialization
	void Start () {

	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void loadLevel(){
		Application.LoadLevel(5);
	}

	void playSound(){
		GetComponent<AudioSource>().Play();
	}

	void  OnTriggerEnter2D(Collider2D collider){
		if(collider.tag=="monkey"){
			Destroy(collider.gameObject);
			Vector3 pos=transform.position;
			pos.y+=0.5f;
			pos.z=-1;
			GameObject monkeyWin = Instantiate(Resources.Load ("monkey_win"),pos,Quaternion.identity) as GameObject;
			iTween.MoveTo(monkeyWin,iTween.Hash("time",0.3,"looptype","pingpong","y",monkeyWin.transform.position.y+1,"easeType","Linear"));
			iTween.MoveTo(this.gameObject,iTween.Hash("time",0.3,"looptype","pingpong","y",monkeyWin.transform.position.y-1,"easeType","Linear"));
			Invoke("loadLevel",2f);//loadlevel after 1.5s
			InvokeRepeating("playSound",0.15f,0.6f);
		}

	}
}
