﻿using UnityEngine;
using System.Collections;

public class Bubble : MonoBehaviour {

	private bool isRaise=false;
	private Rigidbody2D monkeyBody;
	// Use this for initialization
	void Start () {

	}

	private float forceY=2500;
	// Update is called once per frame
	void FixedUpdate () {
		//plus force per frame
		if(monkeyBody&&isRaise){
			monkeyBody.rigidbody2D.gravityScale=0;
			if(forceY<7000){
				forceY+=10;
			}

			Vector2 force = new Vector2(0,forceY);
			force*=Time.deltaTime;
			monkeyBody.AddForce(force);

		}
	}

	void OnTriggerEnter2D(Collider2D other) {

		if(other.tag=="monkey"){
			other.rigidbody2D.isKinematic=true;
			//other.collider2D.enabled=false;
			//this.collider2D.enabled=false;
			Camera.main.GetComponent<Audio>().audioEnterBubble();
			Vector3 pos =this.transform.position;
			pos.y+=0.7f;
			pos.x-=0.7f;
			//play enter bubble animation and  execute callback
			iTween.MoveBy(this.gameObject,iTween.Hash("y",0.3,"time",1,"easetype","easeOutElastic"));
			iTween.MoveTo(other.gameObject,iTween.Hash("x",pos.x,"y",pos.y,"time",1,"easetype","easeOutElastic"));
			iTween.RotateTo(other.gameObject,iTween.Hash("z",30,"time",1,"oncomplete","onEnterBubble","oncompletetarget",this.gameObject,"oncompleteparams",other.gameObject,"easetype","easeOutElastic"));

		}else if(other.tag=="knife"){

			this.collider2D.enabled=false;
			Camera.main.GetComponent<Audio>().audioBubbleBreak();
			isRaise=false;
			this.GetComponent<Animator>().SetBool("isPop",true);
			Destroy(this.gameObject,1);

		}
	}

	//enter bubble animation callback
	void onEnterBubble(GameObject monkey){
		this.transform.parent=monkey.transform;
		isRaise=true;
		monkey.rigidbody2D.isKinematic=false;
		monkeyBody=monkey.rigidbody2D;
		//bubble raise up animation
		GetComponent<Animator>().SetBool("isUp",true);

	}
}
