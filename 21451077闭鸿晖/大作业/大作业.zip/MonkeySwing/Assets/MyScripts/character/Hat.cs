﻿using UnityEngine;
using System.Collections;

public class Hat : MonoBehaviour {
	public GameObject outlet;
	public HingeJoint2D joint;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void fade(){
		iTween.FadeTo(outlet,iTween.Hash("alpha",0,"time",1));
		Destroy(this.gameObject);
		Destroy(outlet,1);
	}

	void outCallback(){
		GameObject monkey = GameObject.Find("monkey");
		monkey.rigidbody2D.isKinematic=false;
		monkey.collider2D.enabled=true;
		monkey.collider2D.isTrigger=false;
		Camera.main.GetComponent<Audio>().audioStart();
		Invoke("fade",0.5f);
	}

	void outletCall(){
		GameObject monkey = GameObject.Find("monkey");
		monkey.transform.position=outlet.transform.position;
		monkey.GetComponent<Animator>().SetBool("scaleMin",false);
		monkey.GetComponent<Animator>().SetBool("scaleMax",true);
		iTween.FadeTo(this.gameObject,iTween.Hash("alpha",0,"time",1));
		Invoke("outCallback",1);
	}

	void OnTriggerEnter2D(Collider2D collider){
		if(collider.tag=="monkey"){
			if(joint!=null){
				joint.enabled=false;
			}
			Camera.main.GetComponent<Audio>().audioStart();
			collider.rigidbody2D.isKinematic=true;
			collider.enabled=false;
			collider.GetComponent<Animator>().SetBool("scaleMin",true);
			iTween.MoveTo(collider.gameObject,iTween.Hash("time",1,"x",transform.position.x,  "y",transform.position.y+1));
			Invoke("outletCall",1.5f);

		}
	}
}
