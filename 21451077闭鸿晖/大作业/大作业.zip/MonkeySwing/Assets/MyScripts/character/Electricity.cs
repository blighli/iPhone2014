using UnityEngine;
using System.Collections;

public class Electricity : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void restart(){
		int currentLevel=Application.loadedLevel;
		Application.LoadLevel(currentLevel);
	}

	void OnTriggerEnter2D(Collider2D collider){
		if(collider.tag=="monkey"){
			collider.rigidbody2D.isKinematic=true;
			iTween.MoveTo(collider.gameObject,iTween.Hash("x",collider.transform.position.x-0.5,"time",0.025,"easetype","linear","looptype","pingpong"));
			Handheld.Vibrate();
			Invoke("restart",2);
		}
	}
}
