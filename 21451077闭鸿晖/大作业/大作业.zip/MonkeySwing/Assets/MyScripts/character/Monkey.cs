﻿using UnityEngine;
using System.Collections;

public class Monkey : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Application.targetFrameRate=60;
	}
	
	// Update is called once per frame
	void Update () {

	}

	void setScaleMaxFalse(){
		GetComponent<Animator>().SetBool("scaleMax",false);
	}

	void setScaleMinFalse(){
		GetComponent<Animator>().SetBool("scaleMin",false);
	}

	void OnTriggerEnter2D(Collider2D other) {
		if(other.tag=="door"){

			Destroy(this.gameObject);
			Vector3 pos=GameObject.Find("door").transform.position;
			pos.z=-1;
		 	GameObject monkeyWin = Instantiate(Resources.Load ("monkey_win"),pos,Quaternion.identity) as GameObject;
			iTween.MoveTo(monkeyWin,iTween.Hash("time",0.3,"looptype","pingpong","y",monkeyWin.transform.position.y+1,"easeType","Linear"));
			Camera.main.GetComponent<Audio>().audioWin();

			int myLevel=PlayerPrefs.GetInt("level",0);
			if(myLevel<4){
				PlayerPrefs.SetInt("level",++myLevel);
			}
			Camera.main.transform.FindChild("knife").gameObject.SetActive(false);
			GameObject.Find("ui").transform.FindChild("winPanel").gameObject.SetActive(true);
		}
	}

}
