﻿using UnityEngine;
using System.Collections;

public class Pump : MonoBehaviour {

	public float force;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {


	}

	public void setTapFalse(){
		GetComponent<Animator>().SetBool("isTap",false);
	}

	public void onTapFinish(Vector2 direction){
		GameObject wind = transform.FindChild("wind").gameObject;
		Vector2 pos  = wind.transform.position;
		pos.x-=direction.x;
		pos.y-=direction.y;
		wind.transform.position=pos;
		iTween.FadeTo(wind,iTween.Hash("alpha",1,"time",0));
		wind.SetActive(false);
		GetComponent<Animator>().SetBool("isTap",false);

	}

	void OnTriggerEnter2D(Collider2D collider){
		if(collider.tag=="knife"){
			//avoid repeat execute animation
			if(GetComponent<Animator>().GetBool("isTap")){
				return;
			}
			GetComponent<AudioSource>().Play();
			GetComponent<Animator>().SetBool("isTap",true);
			float radian = Mathf.PI*transform.rotation.eulerAngles.z/180;
			float x=-Mathf.Sin(radian);
			float y=Mathf.Cos(radian);
			Vector2 direction = new Vector2(x,y);
			direction.Normalize();

			GameObject wind = transform.FindChild("wind").gameObject;
			float windX=wind.transform.position.x+direction.x;
			float windY=wind.transform.position.y+direction.y;

			wind.SetActive(true);
			iTween.FadeTo(wind,iTween.Hash("alpha",1,"time",0));
			iTween.MoveTo(wind,iTween.Hash("time",0.5,"x",windX,"y",windY,"oncomplete","onTapFinish","oncompletetarget",this.gameObject,"oncompleteparams",direction));
			iTween.FadeTo(wind,iTween.Hash("alpha",0,"time",0.5));
			RaycastHit2D hit = Physics2D.Raycast(transform.position,direction,100,1<<8);

			if (hit && hit.collider .tag=="bubble") {
				hit.collider.rigidbody2D.AddForce(direction*force);
			}
		}
	}
}
