﻿using UnityEngine;
using System.Collections;

public class Audio : MonoBehaviour {
	public AudioClip bubbleBreak;
	public AudioClip win;
	public AudioClip lose;
	public AudioClip start;
	public AudioClip monkeyJump;
	public AudioClip monkeyJump2;
	public AudioClip monkeyLaugh;
	public AudioClip enterBubble;

	private AudioSource audioSource;
	// Use this for initialization
	void Start () {
		audioSource=this.GetComponent<AudioSource>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void audioBubbleBreak(){
		audioSource.PlayOneShot(bubbleBreak);
	}

	public void audioWin(){
		audioSource.PlayOneShot(win);
	}

	public void audioStart(){
		audioSource.PlayOneShot(start);
	}

	public void audioMonkeyJump(){
		audioSource.PlayOneShot(monkeyJump);
	}

	public void audioMonkeyJump2(){
		audioSource.PlayOneShot(monkeyJump2);
	}

	public void audioEnterBubble(){
		audioSource.PlayOneShot(enterBubble);
	}
}
