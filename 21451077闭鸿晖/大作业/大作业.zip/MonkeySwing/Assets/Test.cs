﻿using UnityEngine;
using System.Collections;

public class Test : MonoBehaviour {

	// Use this for initialization
	void Start () {
		rigidbody2D.AddForce(new Vector2(1000,0),ForceMode2D.Force);
	}
	
	// Update is called once per frame
	void Update () {

	}
}
