//
//  ImageUtils.h
//  project4
//
//  Created by xuyouyang on 14/11/24.
//  Copyright (c) 2014年 zju-cst. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ImageUtils : NSObject

+ (NSString *)saveImage:(UIImage *)tempImage WithName:(NSString *)imageName;

@end
