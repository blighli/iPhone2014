﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

	public bool facingRight = true;
	public float speed = 1;
	public float jumpForce = 200;
	public Transform groundCheck;
	public Transform faceCheck1;
	public Transform faceCheck2;
	public LayerMask groundLayer;

	private Animator anim;
	private bool gameStarted = false;
	private bool grounded = false;
	private bool faceBlocked = false;

	void Start () {
		anim = GetComponent<Animator> ();
	}

	void Update () {
		if (anim.GetBool ("Dead"))
			return;

		grounded = Physics2D.OverlapArea (new Vector2(groundCheck.position.x-0.36f, groundCheck.position.y+0.1f),
		                                  new Vector2(groundCheck.position.x+0.36f, groundCheck.position.y-0.1f),
		                                  groundLayer);
		anim.SetBool ("Grounded", grounded);
		faceBlocked = Physics2D.Linecast (transform.position, faceCheck1.position, groundLayer) ||
					  Physics2D.Linecast (transform.position, faceCheck2.position, groundLayer);

		if (grounded && Input.GetKeyDown (KeyCode.UpArrow)) {
			rigidbody2D.AddForce(new Vector2(0, jumpForce));
		}
	}

	void FixedUpdate() {
		if (anim.GetBool ("Dead"))
			return;

		if (!gameStarted)
			return;

		if (facingRight && Input.GetKeyDown(KeyCode.LeftArrow))
			Flip ();
		else if (!facingRight && Input.GetKeyDown(KeyCode.RightArrow))
			Flip ();
		else if (faceBlocked)
			Flip ();

		rigidbody2D.velocity = new Vector2 (speed, rigidbody2D.velocity.y);
	}

	void Flip() {
		facingRight = !facingRight;
		Vector3 theScale = transform.localScale;
		theScale.x *= -1;
		transform.localScale = theScale;
		speed *= -1;
	}

	void OnCollisionEnter2D (Collision2D c) {
		gameStarted = true;

		if (c.transform.tag.CompareTo ("Enemy") == 0) {
			anim.SetBool("Dead", true);
			anim.SetBool("Grounded", true);
			rigidbody2D.AddForce(new Vector2(0, jumpForce));
			GetComponent<BoxCollider2D>().isTrigger = true;
		}
	}

	void OnSwipe(SwipeGesture gesture) {
		if (anim.GetBool ("Dead"))
			return;
		
		if (!gameStarted)
			return;

		FingerGestures.SwipeDirection direction = gesture.Direction;
		if (direction == FingerGestures.SwipeDirection.Up) {
			if (grounded) {
				rigidbody2D.AddForce(new Vector2(0, jumpForce));
			}
		}
		if (direction == FingerGestures.SwipeDirection.Left) {
			if (facingRight)
				Flip ();
		}
		if (direction == FingerGestures.SwipeDirection.Right) {
			if (!facingRight)
				Flip ();	
		}
	}
}
