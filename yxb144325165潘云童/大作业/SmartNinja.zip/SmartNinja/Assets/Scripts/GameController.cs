﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GameController : MonoBehaviour {

	public Text scoreText;
	private int score;

	void Start () {
		score = PlayerPrefs.GetInt ("Score", 0);
		scoreText.text = score + "";
	}

	void Update () {
		if(Input.GetKey(KeyCode.Escape)){
			Application.Quit();
		}

	}

}
