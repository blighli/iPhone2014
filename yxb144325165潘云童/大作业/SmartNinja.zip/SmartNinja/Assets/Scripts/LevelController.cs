﻿using UnityEngine;
using System.Collections;

public class LevelController : MonoBehaviour {
	
	void OnCollisionEnter2D (Collision2D c) {

		int score = PlayerPrefs.GetInt ("Score", 0);
		PlayerPrefs.SetInt ("Score", score + 1);

		int i = score + 1;
		if (score >= 4) {
			i = Random.Range (1, 5);
		}
		string level = "LeftDownLevel" + i;

		Application.LoadLevel (level);
	}
}
