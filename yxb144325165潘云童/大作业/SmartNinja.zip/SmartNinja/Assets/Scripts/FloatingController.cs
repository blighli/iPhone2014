﻿using UnityEngine;
using System.Collections;

public class FloatingController : MonoBehaviour {

	public float speed = 0.6f;

	void Update() {
		if (transform.position.x <= -0.85)
			Flip();
		else if (transform.position.x >= 1.2)
			Flip();
	}

	void FixedUpdate() {
		rigidbody2D.velocity = new Vector2 (speed*-1, rigidbody2D.velocity.y);
	}

	void Flip() {
		speed *= -1;
	}
}
