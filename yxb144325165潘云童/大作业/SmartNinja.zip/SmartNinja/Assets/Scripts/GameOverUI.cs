﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameOverUI : MonoBehaviour {

	public Text scoreText;
	public Text bestText;

	private int score;
	private int best;

	void Start () {
		score = PlayerPrefs.GetInt ("Score", 0);
		best = PlayerPrefs.GetInt ("Best", 0);

		if (score > best) {
			PlayerPrefs.SetInt("Best", score);
			best = score;
		}

		scoreText.text = score + "";
		bestText.text = best + "";

		PlayerPrefs.SetInt ("Score", 0);
	}
}
