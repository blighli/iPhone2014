﻿using UnityEngine;
using System.Collections;

public class UpDownController : MonoBehaviour {

	public float speed = 1f;

	void Update() {
		if (transform.position.y <= -1.6)
			speed *= -1;
		if (transform.position.y >= 1.6)
			speed *= -1;
	}

	void FixedUpdate() {
		rigidbody2D.velocity = new Vector2 (rigidbody2D.velocity.x, speed);
	}
}
