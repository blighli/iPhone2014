﻿using UnityEngine;
using System.Collections;

public class NailController : MonoBehaviour {

	private bool showNail = false;
	
	void OnTriggerExit2D (Collider2D c) {
		if (!showNail) {
			iTween.MoveBy (transform.FindChild ("nail").gameObject, iTween.Hash("y", 0.16,
			                                                                    "speed", 0.5,
			                                                                    "easeType", iTween.EaseType.linear));
			showNail = true;
		}
	}
}
