﻿using UnityEngine;
using System.Collections;

public class InitScore : MonoBehaviour {
	
	void Start () {
		Application.targetFrameRate = 60;
		PlayerPrefs.SetInt ("Score", 0);
	}
}
