﻿using UnityEngine;
using System.Collections;

public class GameOver : MonoBehaviour {

	void OnTriggerEnter2D(Collider2D c) {
		Debug.Log ("over");
		Application.LoadLevel ("GameOver");
	}
}
