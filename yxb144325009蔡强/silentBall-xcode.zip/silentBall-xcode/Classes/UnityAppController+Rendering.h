#include "UnityAppController.h"


@interface UnityAppController (Rendering)

- (void)createDisplayLink;
- (void)repaintDisplayLink;

- (void)repaint;

@end
